// layouts
import { Default } from "../template/layouts";

// pages
import { Home, NotFound } from "../template/pages";

export const routes = [
  // These are the same as the props you provide to <Route>
  {
    path: "/",
    element: <Default />,
    children: [
      { path: "", element: <Home /> },
      // { path: "history", element: <History /> },
    ],
  },

  // {
  //   path: "/mobile",
  //   element: <MobileScreen />,
  //   children: [
  //     { path: "contact/:id", element: <Contact /> },
  //     { path: "history/:id", element: <History /> },
  //   ],
  // },

  // Not found routes work as you'd expect
  { path: "*", element: <NotFound /> },
];
