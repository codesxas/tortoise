import Home from "./Home";
import NotFound from "./NotFound";

export { Home, NotFound };
