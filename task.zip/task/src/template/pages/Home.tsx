import React from "react";
import Swiper from "../components/common/Swiper";
import { StickyFooter } from "../components/footer";
import { Banner, FeaturedBanner, Info } from "../components/home";
import { Promise } from "../components/home/info-components";

function Home() {
  return (
    <div className="main">
      <div className="bs-sec">
        <Swiper slidesPerView={1.15} spaceBetween={12}>
          <Banner />
          <Banner />
          <Banner />
          <Banner />
        </Swiper>

        <FeaturedBanner />
        <Info />
      </div>

      <Promise />
      <StickyFooter title="Start Saving" />
    </div>
  );
}

export default Home;
