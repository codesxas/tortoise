import StickyFooter from "./StickyFooter";

export { StickyFooter };
