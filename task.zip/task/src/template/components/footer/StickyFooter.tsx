import React from "react";

type Props = {
  title: string;
};

function DefaultFooter({ title }: Props) {
  return (
    <React.Fragment>
      <div className="footer default">
        <button className="btn btn-primary">{title}</button>
      </div>
    </React.Fragment>
  );
}

export default DefaultFooter;
