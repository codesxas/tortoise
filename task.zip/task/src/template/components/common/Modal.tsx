import React from "react";
import Close from "../../../assets/images/icons/close.svg";

type Props = {
  children: React.ReactNode;
  showModal: boolean;
  onCloseModal: any;
};

type CommonProps = {
  children: React.ReactNode;
};

function Modal(props: Props) {
  const { children, showModal, onCloseModal } = props;

  return (
    <React.Fragment>
      <div className={`custom-modal ${showModal ? "active" : ""}`}>
        <div className="modal-content">
          <div className="close-modal">
            <button type="button" className="btn close" onClick={onCloseModal}>
              <img src={Close} alt="close" />
            </button>
          </div>

          {children}
        </div>
      </div>

      <div className={`overlay ${showModal ? "active" : ""}`}></div>
    </React.Fragment>
  );
}

export default Modal;

export function ModalHeader(props: CommonProps) {
  const { children } = props;

  return <div className="modal-header">{children}</div>;
}

export function ModalBody(props: CommonProps) {
  const { children } = props;

  return <div className="modal-body">{children}</div>;
}

Modal.defaultProps = {
  showModal: false,
};
