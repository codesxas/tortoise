import React from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Pagination, EffectFade, Autoplay } from "swiper";

import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/scrollbar";
import "swiper/css/pagination";
import "swiper/css/effect-fade";
import "swiper/css/autoplay";

type Props = {
  children: React.ReactNode;
  slidesPerView: number;
  spaceBetween: number;
  hasPagination: boolean;
};

function SwiperWrapper(props: Props) {
  const { children, slidesPerView, spaceBetween, hasPagination } = props;

  const hasSingleChild = () => {
    try {
      if (children && Array.isArray(children)) {
        return false;
      } else {
        return true;
      }
    } catch (e) {
      return true;
    }
  };

  const getModules = () => {
    let modules = [Autoplay];

    if (hasPagination) {
      modules.push(Pagination);
    }

    return modules;
  };

  return (
    <Swiper
      modules={getModules()}
      pagination={{ clickable: true }}
      slidesPerView={1}
      spaceBetween={spaceBetween}
      keyboard={{
        enabled: true,
      }}
      breakpoints={{
        375: {
          slidesPerView,
        },
      }}
      className={`carousel ${slidesPerView === 1 ? "" : "rm-0"}`}
      autoplay={{
        delay: 5000,
        disableOnInteraction: false,
      }}
      effect="fade"
    >
      {!hasSingleChild() && Array.isArray(children) ? (
        children.map((item: any, index: number) => {
          return <SwiperSlide key={index}>{item}</SwiperSlide>;
        })
      ) : (
        <SwiperSlide>{children}</SwiperSlide>
      )}
    </Swiper>
  );
}

export default SwiperWrapper;

SwiperWrapper.defaultProps = {
  slidesPerView: 1,
  spaceBetween: 30,
  hasPagination: true,
};
