import Logo from "../../../assets/images/logo/brand_logo.svg";
import Share from "../../../assets/images/icons/share_light.svg";

function Header() {
  return (
    <div className="header">
      <div className="brand-logo">
        <img src={Logo} alt="" />
      </div>

      <div className="share-icon">
        <img src={Share} alt="" />
      </div>
    </div>
  );
}

export default Header;
