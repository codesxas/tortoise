import React, { useState } from "react";
import FAQAccordion from "./FAQAccordion";

function FAQs() {
  const [activeTab, setActiveTab] = useState(0);

  const handleAccordionChange = (
    e: React.MouseEvent<HTMLButtonElement>
  ): void => {
    e.preventDefault();

    const currId = parseInt(e.currentTarget.id);
    setActiveTab(currId);
  };

  return (
    <div className="accordion">
      <FAQAccordion
        id={0}
        activeTab={activeTab}
        handleAccordionChange={handleAccordionChange}
        title="What is tortoise?"
      />
      <FAQAccordion
        id={1}
        activeTab={activeTab}
        handleAccordionChange={handleAccordionChange}
        title="Why should I save on the tortoise app and not in my bank account?"
      />
    </div>
  );
}

export default FAQs;
