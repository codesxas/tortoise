import FAQs from "./FAQs";
import KnowMore from "./KnowMore";
import Reviews from "./Reviews";
import Promise from "./Promise";

export { FAQs, KnowMore, Reviews, Promise };
