import React, { useState } from "react";
import Lock from "../../../../assets/images/icons/lock.svg";
import Modal, { ModalHeader, ModalBody } from "../../common/Modal";

function Promise() {
  const [showModal, setShowModal] = useState(false);

  return (
    <React.Fragment>
      <div className="promise bs-sec">
        <div className="img-wrap">
          <img src={Lock} alt="" />
        </div>

        <div className="info-wrap">
          <p className="info-desc">your money is 100% safe</p>
          <span className="know-more-btn" onClick={() => setShowModal(true)}>
            Know more
          </span>
        </div>
      </div>

      <Modal showModal={showModal} onCloseModal={() => setShowModal(false)}>
        <ModalHeader>
          <img className="modal-logo" src={Lock} alt="lock" />

          <h5 className="modal-heading">TORTOISE PROMISE</h5>
          <h5 className="modal-sub-heading">Your money is 100% safe</h5>
        </ModalHeader>

        <ModalBody>
          <ul className="icon-list">
            <li className="icon-item">
              <span className="icon-wrap"></span>
              <p className="icon-desc">
                Your deposits are safely stored in RBI-regulated escrow
                accounts.
              </p>
            </li>

            <li className="icon-item">
              <span className="icon-wrap"></span>
              <p className="icon-desc">
                Your deposits are safely stored in RBI-regulated escrow
                accounts.
              </p>
            </li>
          </ul>
        </ModalBody>
      </Modal>
    </React.Fragment>
  );
}

export default Promise;
