import React from "react";
import ReviewCard from "./ReviewCard";

function Reviews() {
  return (
    <React.Fragment>
      <ReviewCard />
      <ReviewCard />
      <ReviewCard />
      <ReviewCard />
    </React.Fragment>
  );
}

export default Reviews;
