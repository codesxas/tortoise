import React from "react";
import Star from "../../../../assets/images/icons/star.svg";

function ReviewCard() {
  return (
    <div className="card review">
      <div className="card-body">
        <div className="review-title">
          <div className="avatar-img">{/* <img src="" alt="" /> */}</div>

          <div className="info-wrap">
            <p className="reviewer-name">Rahul Kumar</p>
            <div className="ratings">
              <img src={Star} alt="" />
              <img src={Star} alt="" />
              <img src={Star} alt="" />
            </div>
          </div>
        </div>

        <p className="review-desc">
          Awesome app! Best service ever for Indians and so smooth without
          glitches and also easy to read and analyse!
        </p>
      </div>
    </div>
  );
}

export default ReviewCard;
