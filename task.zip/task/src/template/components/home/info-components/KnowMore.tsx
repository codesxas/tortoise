import React from "react";
import SwiperWrapper from "../../common/Swiper";
import KnowMoreCard from "./KnowMoreCard";

function KnowMore() {
  return (
    <SwiperWrapper hasPagination={false}>
      <KnowMoreCard />
      <KnowMoreCard />
      <KnowMoreCard />
    </SwiperWrapper>
  );
}

export default KnowMore;
