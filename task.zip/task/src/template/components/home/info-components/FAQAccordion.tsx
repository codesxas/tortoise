import React from "react";

type Props = {
  id: number;
  activeTab: number;
  title: string;
  handleAccordionChange: (e: React.MouseEvent<HTMLButtonElement>) => void;
};

function FAQAccordion({ id, activeTab, title, handleAccordionChange }: Props) {
  return (
    <React.Fragment>
      <div className="accordion-item">
        <h2 className="accordion-header">
          <button
            className="accordion-button"
            type="button"
            id={String(id)}
            onClick={handleAccordionChange}
          >
            {title}
          </button>
        </h2>
        <div
          id="collapseOne"
          className={`accordion-collapse ${activeTab === id ? "active" : ""}`}
        >
          <div className="accordion-body">
            It is shown by default, until the collapse plugin adds the
            appropriate classes that we use to style each element.
          </div>
        </div>
      </div>
    </React.Fragment>
  );
}

export default FAQAccordion;
