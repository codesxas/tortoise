import React from "react";
import Device from "../../../../assets/images/device.png";

function KnowMoreCard() {
  return (
    <div className="card shadow know-more">
      <div className="card-body">
        <div className="card-image">
          <img src={Device} alt="iphone" />
        </div>
      </div>
      <div className="card-footer">
        <span className="footer-key">1</span>
        <p className="footer-desc">
          Set up your savings plan by selecting your goal amount and duration.
          Make your first deposit to get started.
        </p>
      </div>
    </div>
  );
}

export default KnowMoreCard;
