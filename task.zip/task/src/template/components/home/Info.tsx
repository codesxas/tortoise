import React, { useState } from "react";
import FAQs from "./info-components/FAQs";
import KnowMore from "./info-components/KnowMore";
import Reviews from "./info-components/Reviews";

function Info() {
  const [activeTab, setActiveTab] = useState(0);

  const handleTabChange = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();

    const currId = parseInt(e.currentTarget.id);
    setActiveTab(currId);
  };
  return (
    <React.Fragment>
      <div className="tab-container home">
        <div className="nav-tabs">
          <button
            className={`nav-item ${activeTab === 0 ? "active" : ""}`}
            id="0"
            onClick={handleTabChange}
          >
            Know more
          </button>

          <button
            className={`nav-item ${activeTab === 1 ? "active" : ""}`}
            id="1"
            onClick={handleTabChange}
          >
            FAQs
          </button>

          <button
            className={`nav-item ${activeTab === 2 ? "active" : ""}`}
            id="2"
            onClick={handleTabChange}
          >
            Reviews
          </button>
        </div>
        <div className="tab-content">
          <div className={`tab-pane ${activeTab === 0 ? "active" : ""}`}>
            <KnowMore />
          </div>
          <div className={`tab-pane ${activeTab === 1 ? "active" : ""}`}>
            <FAQs />
          </div>
          <div className={`tab-pane ${activeTab === 2 ? "active" : ""}`}>
            <Reviews />
          </div>
        </div>
      </div>
    </React.Fragment>
  );
}

export default Info;
