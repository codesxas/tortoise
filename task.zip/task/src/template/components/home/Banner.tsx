import React from "react";
import BannerImage from "../../../assets/images/banner_image.png";
import Apple from "../../../assets/images/logo/apple.svg";
import Charger from "../../../assets/images/icons/charger.svg";
import Truck from "../../../assets/images/icons/truck.svg";
import Gift from "../../../assets/images/icons/gift.svg";

function Banner() {
  return (
    <div className="card shadow">
      <div className="card-body">
        <div className="card-image">
          <img src={BannerImage} alt="iphone" />
        </div>

        <div className="product-logo">
          <img src={Apple} alt="brand-logo" />
        </div>

        <div className="icon-wrap">
          <div className="icon-item">
            <div className="icon bg-turquoise">
              <img src={Charger} alt="" />
            </div>
            <p className="icon-desc">Priority Delivery</p>
          </div>

          <div className="icon-item">
            <div className="icon bg-yellow">
              <img src={Truck} alt="" />
            </div>
            <p className="icon-desc">Free Charger</p>
          </div>

          <div className="icon-item">
            <div className="icon bg-green">
              <img src={Gift} alt="" />
            </div>
            <p className="icon-desc">Tortoise Merchandise</p>
          </div>
        </div>
      </div>
      <div className="card-footer">
        <span className="footer-desc">
          Save up for the next iPhone launch. Earn 10% rewards.
        </span>
      </div>
    </div>
  );
}

export default Banner;
