import React from "react";
import ET from "../../../assets/images/logo/et.png";
import FE from "../../../assets/images/logo/fe.png";
import Inc4s from "../../../assets/images/logo/inc4s.png";

function FeaturedBanner() {
  return (
    <div className="card featured">
      <div className="card-body">
        <p className="f-title">
          Featured in
          <span className="f-title__dark">Top Publications</span>
        </p>

        <div className="f-list">
          <div className="f-item">
            <img src={ET} alt="" />
          </div>
          <div className="f-item">
            <img src={FE} alt="" />
          </div>
          <div className="f-item">
            <img src={Inc4s} alt="" />
          </div>
        </div>
      </div>
    </div>
  );
}

export default FeaturedBanner;
