import React from "react";
import Header from "../components/header/DefaultHeader";
import { Outlet } from "react-router-dom";

function Default() {
  return (
    <React.Fragment>
      <Header />
      <Outlet />
    </React.Fragment>
  );
}

export default Default;
